package com.snhu.sslserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.security.MessageDigest;

@SpringBootApplication
public class SslServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SslServerApplication.class, args);
	}

}
@RestController
class ChecksumController {

    @GetMapping("/hash")
    public String getChecksum() throws Exception {
        // Data and Name
        String data = "Checksum Verification";
        String name = "Matthew Bridegroom";

        // Algorithm used SHA-256
        String algorithmUsed = "SHA-256";

        // Compute SHA-256 hash for the data
        MessageDigest digest = MessageDigest.getInstance(algorithmUsed);
        byte[] hash = digest.digest(data.getBytes("UTF-8"));

        // Convert hash to hex string
        StringBuilder hexString = new StringBuilder();
        for (byte b : hash) {
            String hex = Integer.toHexString(0xff & b);
            if (hex.length() == 1) hexString.append('0');
            hexString.append(hex);
        }

        // Return the formatted string with HTML line breaks
        return "Data:<br>" + data + "<br><br>" +
               "Name:<br>" + name + "<br><br>" +
               "Name of Algorithm Used:<br>" + algorithmUsed + "<br><br>" +
               "Checksum:<br>" + hexString.toString();
    }
}